# Real Estate Lead Engine

Full technical infrastructure for a Nigerian real estate lead-qualification
site: a browsable property catalogue, a multi-step qualification + viewing
scheduler form, a WhatsApp-based handoff to agents, and an agent-facing
pipeline dashboard.

## Stack

Next.js 14 (App Router) · TypeScript · Tailwind CSS · React Hook Form + Zod ·
Supabase (Postgres + RLS + Auth)

## Project structure

```
supabase/migrations/0001_init.sql       -- properties, leads, viewings + RLS
types/database.ts                       -- hand-written types mirroring the SQL schema
lib/schemas.ts                          -- Zod schemas (single source of truth for the forms)
lib/formatNaira.ts                      -- ₦ currency formatting
lib/budgetRanges.ts                     -- budget-bracket → numeric bounds, for search filtering
lib/generateWhatsAppLink.ts             -- pure WhatsApp message + wa.me link builder
lib/analytics.ts                        -- PostHog / GA4 / Meta Pixel event dispatch
lib/actions/submitLead.ts               -- Server Action: validates + inserts a lead
lib/actions/submitViewing.ts            -- Server Action: validates + inserts a viewing request
lib/supabase/client.ts                  -- browser Supabase client (anon key)
lib/supabase/server.ts                  -- Server Component Supabase client (anon key)
lib/supabase/admin.ts                   -- service-role client, server-only, admin use only

app/page.tsx                            -- homepage: hero, search/filter, property grid (CORE 01)
app/sitemap.ts                          -- dynamic XML sitemap (homepage + every published property)
app/properties/[slug]/page.tsx          -- listing page: metadata, JSON-LD, gallery, CTA
app/admin/login/page.tsx                -- agent login page
app/admin/page.tsx                      -- agent dashboard: leads pipeline + viewing requests
app/admin/actions.ts                    -- Server Actions: update lead status, sign out
middleware.ts                           -- protects /admin/* behind a Supabase Auth session

components/PropertySearchForm.tsx       -- plain GET form filter bar (no client JS)
components/PropertyCard.tsx             -- homepage grid card
components/LeadQualificationForm.tsx    -- 5-step qualification form + optional 6th viewing step
components/PropertyInquiryLauncher.tsx  -- modal trigger + sticky mobile CTA bar
components/PropertyMediaGallery.tsx     -- image carousel/lightbox
components/AdminLoginForm.tsx           -- agent sign-in form
```

## Setup

1. **Create a Supabase project**, then run the migration:
   ```bash
   npx supabase db push
   # or paste supabase/migrations/0001_init.sql into the SQL editor
   ```
2. **Grant base table privileges.** RLS policies alone aren't enough —
   Postgres also requires an explicit `GRANT` before a role can query a
   table at all, and creating tables via raw SQL (rather than Supabase's
   table-builder UI) skips this. Run once in the SQL Editor:
   ```sql
   grant usage on schema public to anon, authenticated;
   grant select on public.properties to anon, authenticated;
   grant insert on public.leads to anon, authenticated;
   grant insert on public.viewings to anon, authenticated;
   ```
3. **Create the agent's login manually.** There is deliberately no public
   sign-up page — Supabase Dashboard → **Authentication → Users → Add user**,
   set an email + password for the agent. That's the only account that can
   reach `/admin`.
4. **Copy env vars**: `cp .env.example .env.local` and fill in your Supabase
   URL/keys.
5. **Install and run locally**:
   ```bash
   npm install
   npm run dev
   ```
6. **Add at least one property row** in Supabase (via the table editor) with
   a `slug`, `agent_whatsapp` in `+234...` or `0...` format, and
   `published = true` so it's visible under RLS.

## Deploying to Vercel

1. Push this repo to GitHub (make sure `package.json` sits at the repo
   root, not nested in a subfolder — Vercel's Next.js auto-detection needs
   that).
2. Import it in Vercel — Framework Preset should auto-detect **Next.js**.
3. Add the same four env vars from `.env.local` into **Project Settings →
   Environment Variables** (all three environments: Production, Preview,
   Development).
4. Deploy, then trigger it again any time an env var changes — editing a
   variable alone does not redeploy.

## Demo walkthrough (for showing prospective clients)

1. **Homepage** (`/`) — browse the catalogue, filter by state / bedrooms /
   budget. Filtering reloads the page with query params (`?state=Lagos`), no
   client JS required, fast on mobile networks.
2. **Property page** (`/properties/[slug]`) — click any card. Full listing
   with gallery, specs, Schema.org JSON-LD for SEO.
3. **Inquire via WhatsApp** — walk through the 5-step qualification form.
   On the contact step, the lead is saved to Supabase. The 6th step offers
   an optional viewing request (date/time/mode) before redirecting to
   WhatsApp with a pre-filled message containing every answer.
4. **Agent dashboard** (`/admin`) — log in with the agent account created
   in Setup step 3. See every lead with its qualification answers, update
   its pipeline status inline, and see every viewing request underneath.

## What's intentionally not built

- **Photo upload UI** — properties currently need their `media` JSON field
  populated directly in Supabase's table editor; there's no in-app image
  uploader.
- **Multi-agent support** — the admin dashboard shows *all* leads to *any*
  logged-in agent; there's no per-agent filtering or role separation.
- **Editable viewing status** — the dashboard's viewings table is read-only;
  updating a viewing's status (confirmed/rescheduled/etc.) isn't wired up.
- **Pagination** on the homepage grid — fine for a demo catalogue, would
  need addressing before hundreds of live listings.

## Notes worth knowing before you demo this

- **RLS vs. table grants**: RLS policies control *which rows* a role can
  see once it's already allowed to query a table; Postgres separately
  requires a base `GRANT` before that. Setup step 2 above is not optional.
- **Env vars only apply after a restart/redeploy** — Next.js reads
  `.env.local` at server startup, and Vercel only applies env var changes
  on the *next* deploy, not retroactively.
- **The WhatsApp + analytics handoff** (`proceedToWhatsApp` in
  `LeadQualificationForm.tsx`) awaits a short grace window
  (`trackEventBeforeRedirect`, 250ms) before redirecting — some mobile
  browsers suspend JS execution the instant navigation starts, which can
  silently drop analytics calls that haven't left the page yet. Worth
  testing on a real device with network throttling before trusting the
  funnel numbers.
- **Service-role key**: only ever used server-side (`lib/supabase/admin.ts`,
  imported only into `app/admin/*`), never shipped to the browser. Mark it
  as a **Secret** (not "Config") in Vercel's environment variable settings.
